Custom Adminer
==============

Our custom all-in-one configuration of Adminer database tool ([www.adminer.org](http://www.adminer.org/)).

It contains [responsive touch-friendly theme](https://github.com/pematon/adminer-theme) and couple of useful [plugins](https://github.com/pematon/adminer-plugins).

## Compatibility
Minimal requirements are: PHP 5.4, Adminer 4.4.0, modern web browser.

## How to use
Just download whole package to public directory on your web server. Optionally you can configure plugins in index.php.
